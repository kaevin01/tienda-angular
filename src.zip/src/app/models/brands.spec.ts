import { Brands } from './brands';

describe('Brands', () => {
  it('should create an instance', () => {
    expect(new Brands()).toBeTruthy();
  });
});
